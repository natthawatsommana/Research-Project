from django.db import models
from app_teachers.models import Prapositions, Teachers

class Students(models.Model):
    student_id = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=255)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    teacher = models.ForeignKey(Teachers, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.student_id} {self.first_name} {self.last_name} อาจารย์ผู้สอน : {self.teacher}"

    class Meta:
        db_table = 'students'
        verbose_name = "Student"             # ชื่อเอกพจน์ที่แสดงใน admin
        verbose_name_plural = "Students"     # ชื่อพหูพจน์ที่แสดงใน admin


class ChallengeProgress(models.Model):
    DIFFICULTY_CHOICES = [
    ('easy', 'Easy'),
    ('medium', 'Medium'),
    ('hard', 'Hard'),
    ]
    student = models.ForeignKey(Students, on_delete=models.CASCADE)
    current_difficulty = models.CharField(max_length=50, choices=DIFFICULTY_CHOICES)
    score = models.IntegerField()
    status = models.BooleanField()

    class Meta:
        db_table = 'challenge_progress'  # ใช้ชื่อนี้แทนชื่ออัตโนมัติ

class PracticeRecords(models.Model):
    student = models.ForeignKey(Students, on_delete=models.CASCADE)
    praposition = models.ForeignKey(Prapositions, on_delete=models.CASCADE)
    solved = models.BooleanField()
    stars = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'practicerecords'  # ใช้ชื่อนี้แทนชื่ออัตโนมัติ

class ChallengeDetail(models.Model):
    progress = models.ForeignKey(ChallengeProgress, on_delete=models.CASCADE)
    praposition = models.ForeignKey(Prapositions, on_delete=models.CASCADE)
    solved = models.BooleanField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'challenge_detail'