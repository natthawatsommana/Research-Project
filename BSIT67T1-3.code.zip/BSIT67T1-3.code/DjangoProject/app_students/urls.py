from django.urls import path
from . import views
from django.contrib import admin
# from .views_login import login_view

urlpatterns = [
    path('', views.students, name='students'),
    path('practice/', views.practice_view, name='practice_view'),
    # path('student-truth-table/<int:praposition_id>/', views.student_truth_table_view, name='student_truth_table'),
    path('practice/<int:praposition_id>/', views.practice_detail_view, name='practice_detail'),
    path('api/save-practice-record/', views.save_practice_record_api, name='save_practice_record_api'), # ✅ เพิ่มตรงนี้
    path('submit-answer-practice/<int:praposition_id>/', views.submit_answer_practice, name='submit_answer_practice'),
    path('challenge/', views.challenge_mode_view, name='challenge_mode'),
    path('challenge/api/progress/', views.get_challenge_progress_api, name='challenge_progress_api'),
    path('challenge/start/<str:difficulty>/', views.challenge_start_view, name='start_challenge'),
    path('challenge-truth-table/<int:praposition_id>/', views.challenge_truth_table_view, name='challenge_truth_table'),
    # path('challenge/attempt/<int:attempt_id>/question/', views.challenge_truth_table_view, name='challenge_truth_table_view'),
    path('submit-answer-challenge/<int:praposition_id>/', views.submit_answer_challenge, name='submit_answer_challenge'),
    path('home',views.home_view,name='home_view'),
    path('change-password', views.change_password, name='change_password'),
    path('register/', views.student_register_view, name='student_register'),
    path('reveal_answer/<int:praposition_id>/', views.reveal_answer_view, name='reveal_answer'),

]