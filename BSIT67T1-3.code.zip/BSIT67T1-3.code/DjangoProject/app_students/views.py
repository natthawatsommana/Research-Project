import json
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render, redirect
from app_teachers.models import *
from django.utils import timezone
from .models import *
from django.core.paginator import Paginator
from django.contrib import messages
from django.contrib import messages
from core.logic.truth_table import generate_truth_table_data
from django.views.decorators.csrf import csrf_exempt

# Create your views here.

def std_home(request):
    student = request.user
    return render(request, 'std_home.html', {
        'student': student
    })

def students(request):
    student_id = request.session.get('user_id')
    student = Students.objects.get(id=student_id)

    context = {
    'student': student}

    return render(request, 'app_students/std_home.html',context)

def student_register_view(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        teacher_id = request.POST.get('teacher_id')

        if Students.objects.filter(student_id=student_id).exists():
            return render(request, 'app_students/register.html', {
                'error': 'มีรหัสนักศึกษานี้อยู่ในระบบแล้ว',
                'teachers': Teachers.objects.all(),
                'first_name': first_name,
                'last_name': last_name,
                'password': password,
                'teacher_id': teacher_id
            })

        teacher = Teachers.objects.get(id=teacher_id)

        Students.objects.create(
            student_id=student_id,
            first_name=first_name,
            last_name=last_name,
            password=password,
            teacher=teacher
        )
        return render(request, 'app_students/register.html', {'success': True})

    teachers = Teachers.objects.all()
    return render(request, 'app_students/register.html', {'teachers': teachers})

#ดึง API
def practice_view(request):
    if request.session.get('user_role') != 'student':
        return redirect('login')
    
    student_id = request.session.get('user_id')
    student = get_object_or_404(Students, id=student_id) # ใช้ get_object_or_404 แทน Objects.get()

    selected_difficulty = request.GET.get('difficulty')
    
    # กรองโจทย์เฉพาะที่เป็นของอาจารย์ของนักเรียนคนนี้ และสถานะเป็น 'practice'
    prapositions_query = Prapositions.objects.filter(
        teacher=student.teacher, 
        status='practice'
    ).order_by('-id') # เรียงลำดับจากใหม่ไปเก่า

    if selected_difficulty:
        prapositions_query = prapositions_query.filter(difficulty=selected_difficulty)
    
    praposition_list = []
    for p in prapositions_query:
        try:
            record = PracticeRecords.objects.get(student=student, praposition=p)
            stars = record.stars
        except PracticeRecords.DoesNotExist:
            stars = 0

        # แปลง prop ให้มี field star_count
        p.star_count = stars
        praposition_list.append(p)
    # แบ่งหน้า (Pagination)
    paginator = Paginator(prapositions_query, 6) # แสดง 10 ข้อต่อหน้า
    page_number = request.GET.get('page')
    prapositions = paginator.get_page(page_number)

    # คำนวณสถิติ
    total_completed_questions = PracticeRecords.objects.filter(
        student=student, 
        praposition__teacher=student.teacher, 
        solved=True
    ).count()
    total_available_questions = Prapositions.objects.filter(
        teacher=student.teacher, 
        status='practice'
    ).count()
    
    success_rate = 0
    if total_available_questions > 0:
        success_rate = round((total_completed_questions / total_available_questions) * 100, 2)
    

    context = { 
        'student': student,
        'prapositions': prapositions, # ส่งแค่ Praposition objects ไปยัง template
        'selected_difficulty': selected_difficulty,
        'success_rate': success_rate,
        'total_completed_questions': total_completed_questions,
        'total_available_questions': total_available_questions,
    }
    return render(request, 'app_students/practice.html', context)


def practice_detail_view(request, praposition_id):
    if request.session.get('user_role') != 'student':
        return redirect('login')

    student_id = request.session.get('user_id')
    student = get_object_or_404(Students, id=student_id)
    praposition_obj = get_object_or_404(Prapositions, id=praposition_id)

    try:
        # สร้างตารางค่าความจริง
        truth_table_result = generate_truth_table_data(praposition_obj.praposition)
        
        # ตรวจสอบว่าดูเฉลยแล้วหรือยัง
        revealed_answer = False
        if 'revealed_answers' in request.session:
            revealed_answer = request.session['revealed_answers'].get(str(praposition_id), False)
        else:
            request.session['revealed_answers'] = {}
        
        try:
            record = PracticeRecords.objects.get(student=student, praposition=praposition_obj)
            star_count = record.stars
        except PracticeRecords.DoesNotExist:
            star_count = 0
        context = {
            'student': student,
            'revealed_answer': revealed_answer,
            'praposition_data': {
                'id': praposition_obj.id,
                'difficulty': praposition_obj.difficulty,
                'praposition': praposition_obj.praposition,
                'status': praposition_obj.status,
                'truth_table_data': truth_table_result.get('test_data'), 
                'correct_table': truth_table_result.get('correct_data'),
                'columns': truth_table_result.get('columns'),
                'correct_table_json': json.dumps(truth_table_result.get('correct_data')),
                'star_count':star_count,
            }
        }
        return render(request, 'app_students/practice_detail.html', context)

    except Exception as e:
        messages.error(request, f"เกิดข้อผิดพลาดในการสร้างตารางค่าความจริง: {e}")
        import traceback
        traceback.print_exc()
        return redirect('practice_view')

def reveal_answer_view(request, praposition_id):
    if 'revealed_answers' not in request.session:
        request.session['revealed_answers'] = {}

    request.session['revealed_answers'][str(praposition_id)] = True
    request.session.modified = True
    return JsonResponse({'success': True})

@csrf_exempt
def save_practice_record_api(request):
    if request.method == 'POST':
        if request.session.get('user_role') != 'student':
            return JsonResponse({'success': False, 'error': 'Unauthorized'}, status=401)
        
        try:
            data = json.loads(request.body)
            praposition_id = data.get('praposition_id')
            solved_status = data.get('solved') # true/false
            stars = data.get('stars',0)

            student_id = request.session.get('user_id')
            student = get_object_or_404(Students, id=student_id)
            praposition = get_object_or_404(Prapositions, id=praposition_id)

            record, created = PracticeRecords.objects.update_or_create(
                student=student,
                praposition=praposition,
                defaults={'solved': solved_status, 'timestamp': timezone.now(),'stars':stars}
            )
            
            # หากต้องการเพิ่ม logic สำหรับ ChallengeProgress ให้ทำที่นี่
            # เช่น ถ้าทำโจทย์ practice ถูกครบตามจำนวนที่กำหนด อาจจะอัปเดต ChallengeProgress

            return JsonResponse({'success': True, 'message': 'Practice record saved.'})
        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'error': 'Invalid JSON format'}, status=400)
        except Prapositions.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Proposition not found'}, status=404)
        except Students.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Student not found'}, status=404)
        except Exception as e:
            import traceback
            traceback.print_exc()
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)

def submit_answer_practice(request, praposition_id):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            student_answers = data.get('answers', [])

            if 'student_truth_table_data' not in request.session or str(praposition_id) not in request.session['student_truth_table_data']:
                return JsonResponse({'success': False, 'error': 'ไม่พบข้อมูลตาราง กรุณาโหลดหน้าใหม่'})

            session_data = request.session['student_truth_table_data'][str(praposition_id)]
            test_data = session_data['test_data']
            correct_data = session_data['correct_data']

            total_score = 0
            total_questions = 0
            answer_details = []

            student_answer_map = {
                f"{answer['row']}-{answer['col']}": answer['value']
                for answer in student_answers
            }

            for row_idx, row in enumerate(test_data):
                for col_idx, cell in enumerate(row):
                    if cell == "___":
                        total_questions += 1
                        key = f"{row_idx}-{col_idx}"
                        student_answer = student_answer_map.get(key, "")
                        correct_answer = correct_data[row_idx][col_idx]
                        is_correct = student_answer == correct_answer
                        if is_correct:
                            total_score += 1
                        answer_details.append({
                            'row': row_idx,
                            'col': col_idx,
                            'student_answer': student_answer,
                            'correct_answer': correct_answer,
                            'is_correct': is_correct
                        })

            score_percentage = (total_score / total_questions * 100) if total_questions > 0 else 0

            # บันทึก PracticeRecord
            student_id = request.session.get('user_id')
            student = Students.objects.get(id=student_id)
            praposition = Prapositions.objects.get(id=praposition_id)
            solved = score_percentage == 100

            revealed = request.session.get('revealed_answers', {}).get(str(praposition_id), False)

            if revealed:
                stars = 0
            else:
                if score_percentage == 100: 
                    stars = 3
                elif score_percentage >= 75:
                    stars = 2
                elif score_percentage >= 50:
                    stars = 1
                else:
                    stars = 0

            record, created = PracticeRecords.objects.get_or_create(
                student=student,
                praposition=praposition,
                defaults={'solved': solved, 'timestamp': timezone.now(),'stars': stars}
            )

            if not created:
                if stars > record.stars and not record.solved and solved :
                    record.stars = stars
                    record.solved = True
                    record.timestamp = timezone.now()
                    record.save()

            return JsonResponse({
                'success': True,
                'total_score': total_score,
                'total_questions': total_questions,
                'score_percentage': round(score_percentage, 2),
                'answer_details': answer_details
            })

        except Exception as e:
            import traceback
            traceback.print_exc()
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})




#ส่วนที่2
def challenge_mode_view(request):
    """หน้าแสดง Challenge Mode พร้อมแสดงความคืบหน้า"""
    if 'user_id' not in request.session:
        return redirect('login')

    student_id = request.session.get('user_id')
    student = get_object_or_404(Students, id=student_id)
    teacher = student.teacher

    # ดึงเงื่อนไขจากอาจารย์
    try:
        conditions = ChallengeCondition.objects.get(created_by=teacher)
    except ChallengeCondition.DoesNotExist:
       return render(request, 'app_students/challenge_error.html', {'student': student})

    # ดึงความคืบหน้าของนักเรียน
    try:
        progress = ChallengeProgress.objects.get(student=student)
    except ChallengeProgress.DoesNotExist:
        # สร้างความคืบหน้าใหม่ถ้ายังไม่มี
        progress = ChallengeProgress.objects.create(
            student=student,
            current_difficulty='easy',
            score=0,
            status=False
        )

    # คำนวณสถิติของแต่ละระดับ
    stats = get_challenge_stats(student, teacher, conditions)

    context = {
        'conditions': {
            'easy_score_per_question': conditions.easy_score_per_question,
            'normal_score_per_question': conditions.normal_score_per_question,
            'hard_score_per_question': conditions.hard_score_per_question,
            'easy_required_to_unlock_normal': conditions.easy_required_to_unlock_normal,
            'normal_required_to_unlock_hard': conditions.normal_required_to_unlock_hard,
        },
        'progress': {
            'current_difficulty': progress.current_difficulty,
            'score': progress.score,
            'status': progress.status,
        },
        'stats': stats,
        'student': student
    }

    return render(request, 'app_students/challenge.html', context)

#หลังดึง API
def challenge_truth_table_view(request,praposition_id):
    if request.session.get('user_role') != 'student':
        return redirect('login')
    
    students_id = request.session.get('user_id')
    student = get_object_or_404(Students,id=students_id)

    #ดึงโจทย์
    praposition_obj = get_object_or_404(Prapositions,id=praposition_id)


    #สร้างตารางค่าความจริง
    try:
        truth_table_result = generate_truth_table_data(praposition_obj.praposition)


        test_data = truth_table_result.get('test_data')
        correct_data = truth_table_result.get('correct_data')
        columns = truth_table_result.get('columns')

        if 'challenge_truth_table_data' not in request.session:
            request.session['challenge_truth_table_data'] = {}
        request.session['challenge_truth_table_data'][str(praposition_id)] = {
            'test_data': test_data,
            'correct_data': correct_data,
            'columns': columns # อาจจะเก็บหรือไม่เก็บก็ได้ขึ้นอยู่กับการใช้งาน
        }
        request.session.modified = True # แจ้งให้ Django ทราบว่า session ถูกแก้ไขแล้ว
        
        context = {
            'student': student,
            'praposition_id': praposition_obj.id, 
            'equation': praposition_obj.praposition, 
            'test_data': truth_table_result.get('test_data'), 
            'correct_data': truth_table_result.get('correct_data'),
            'columns': truth_table_result.get('columns'),
            'difficulty': praposition_obj.difficulty,
            }
        return render(request,'app_students/challenge_truth_table.html',context)
    except Exception as e:
        messages.error(request, f"เกิดข้อผิดพลาดในการสร้างตารางค่าความจริง: {e}")
        return redirect('challenge_mode') # กลับไปหน้ารายการโจทย์

def get_challenge_stats(student, teacher, conditions):
    """คำนวณสถิติของแต่ละระดับ"""
    stats = {}

    for difficulty in ['easy', 'medium', 'hard']:
        # นับจำนวนโจทย์ทั้งหมดในระดับนี้
        total_questions = Prapositions.objects.filter(
            teacher=teacher,
            status='challenge',
            difficulty=difficulty
        ).count()

        # นับจำนวนโจทย์ที่ทำแล้ว
        solved_questions = ChallengeDetail.objects.filter(
            progress__student=student,
            praposition__difficulty=difficulty,
            praposition__status='challenge',
            solved=True
        ).count()

        stats[difficulty] = {
            'solved': solved_questions,
            'total': total_questions
        }

    return stats

def get_challenge_progress_api(request):
    """API สำหรับดึงข้อมูลความคืบหน้า (ใช้กับ AJAX)"""
    if 'user_id' not in request.session:
        return JsonResponse({'error': 'Not authenticated'}, status=401)

    student_id = request.session.get('user_id')
    student = get_object_or_404(Students, id=student_id)
    teacher = student.teacher

    try:
        conditions = ChallengeCondition.objects.get(created_by=teacher)
    except ChallengeCondition.DoesNotExist:
        return render(request, 'app_students/challenge_error.html', {'student': student})

    try:
        progress = ChallengeProgress.objects.get(student=student)
    except ChallengeProgress.DoesNotExist:
        progress = ChallengeProgress.objects.create(
            student=student,
            current_difficulty='easy',
            score=0,
            status=False
        )

    stats = get_challenge_stats(student, teacher, conditions)

    return JsonResponse({
        'conditions': {
            'easy_score_per_question': conditions.easy_score_per_question,
            'normal_score_per_question': conditions.normal_score_per_question,
            'hard_score_per_question': conditions.hard_score_per_question,
            'easy_required_to_unlock_normal': conditions.easy_required_to_unlock_normal,
            'normal_required_to_unlock_hard': conditions.normal_required_to_unlock_hard,
        },
        'progress': {
            'current_difficulty': progress.current_difficulty,
            'score': progress.score,
            'status': progress.status,
        },
        'stats': stats
    })

def challenge_start_view(request, difficulty):
    if 'user_id' not in request.session:
        return redirect('login')

    student_id = request.session.get('user_id')
    student = Students.objects.get(id=student_id)
    teacher = student.teacher

    if difficulty not in ['easy', 'medium', 'hard']:
        return render(request, 'app_students/error.html', {'message': 'ระดับความยากไม่ถูกต้อง'})

    #ดึงโจทย์ในระดับที่ต้องการ
    prapositions = Prapositions.objects.filter(
        teacher=teacher,
        status='challenge',
        difficulty=difficulty
    )

    #ดึง progress ทั้งหมดของนักเรียน
    progresses = ChallengeProgress.objects.filter(student=student)

    #ดึง ChallengeDetail ที่ผูกกับ progress เหล่านี้
    details = ChallengeDetail.objects.filter(progress__in=progresses)

    #คัด filter เฉพาะ praposition ที่อยู่ในระดับนี้เท่านั้น
    solved_ids = [d.praposition_id for d in details if d.solved and d.praposition.difficulty == difficulty]
    unsolved_ids = [d.praposition_id for d in details if not d.solved and d.praposition.difficulty == difficulty]
    total_questions = prapositions.count()
    solved_count = len(solved_ids)
    success_rate = int((solved_count / total_questions) * 100) if total_questions > 0 else 0

    paginator = Paginator(prapositions, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'student':student,
        'difficulty': difficulty,
        'prapositions': prapositions,
        'solved_ids': solved_ids,
        'unsolved_ids': unsolved_ids,
        'total_questions': total_questions,
        'solved_count': solved_count,
        'success_rate': success_rate,
        'prapositions': page_obj,
    }

    return render(request, 'app_students/challenge_start.html', context)


def is_difficulty_unlocked(student, difficulty):
    """ตรวจสอบว่าระดับความยากนี้ปลดล็อกแล้วหรือยัง"""
    if difficulty == 'easy':
        return True

    teacher = student.teacher
    try:
        conditions = ChallengeCondition.objects.get(created_by=teacher)
    except ChallengeCondition.DoesNotExist:
        return False  # ถ้าไม่มีเงื่อนไข ให้เล่นได้แค่ระดับง่าย

    if difficulty == 'medium':
        easy_solved = ChallengeDetail.objects.filter(
            progress__student=student,
            praposition__difficulty='easy',
            solved=True
        ).count()
        return easy_solved >= conditions.easy_required_to_unlock_normal

    elif difficulty == 'hard':
        medium_solved = ChallengeDetail.objects.filter(
            progress__student=student,
            praposition__difficulty='medium',
            solved=True
        ).count()
        return medium_solved >= conditions.normal_required_to_unlock_hard

    return False

def submit_answer_challenge(request, praposition_id):
    try:
        data = json.loads(request.body)
        student_answers = data.get('answers', [])

        if 'challenge_truth_table_data' not in request.session or str(praposition_id) not in request.session['challenge_truth_table_data']:
            return JsonResponse({'success': False, 'error': 'ไม่พบข้อมูลตาราง กรุณาโหลดหน้าใหม่'})

        session_data = request.session['challenge_truth_table_data'][str(praposition_id)]
        test_data = session_data['test_data']
        correct_data = session_data['correct_data']

        #ดึงข้อมูล student และ praposition
        student_id = request.session.get('user_id')
        student = Students.objects.get(id=student_id)
        teacher = student.teacher
        praposition = Prapositions.objects.get(id=praposition_id)
        solved = False  # จะเปลี่ยนเป็น True ถ้าทำได้ 100%

        #ดึง ChallengeCondition ของครูที่สร้างโจทย์นี้
        challenge_condition = ChallengeCondition.objects.get(created_by=teacher)

        #ตรวจสอบระดับเพื่อเอาคะแนนต่อข้อ
        level = praposition.difficulty
        if level == 'easy':
            score_per_question = challenge_condition.easy_score_per_question
        elif level == 'medium':
            score_per_question = challenge_condition.normal_score_per_question
        elif level == 'hard':
            score_per_question = challenge_condition.hard_score_per_question
        else:
            score_per_question = 1  # fallback default

        total_score = 0
        total_questions = 0
        answer_details = []

        student_answer_map = {
            f"{answer['row']}-{answer['col']}": answer['value']
            for answer in student_answers
        }

        for row_idx, row in enumerate(test_data):
            for col_idx, cell in enumerate(row):
                if cell == "___":
                    total_questions += 1
                    key = f"{row_idx}-{col_idx}"
                    student_answer = student_answer_map.get(key, "")
                    correct_answer = correct_data[row_idx][col_idx]
                    is_correct = student_answer == correct_answer
                    if is_correct:
                        total_score += 1
                    answer_details.append({
                        'row': row_idx,
                        'col': col_idx,
                        'student_answer': student_answer,
                        'correct_answer': correct_answer,
                        'is_correct': is_correct
                    })

        max_score = total_questions * 1 if total_questions > 0 else 1
        score_percentage = (total_score / max_score * 100)

        solved = score_percentage == 100

        #ดึง progress ของ student
        progress = ChallengeProgress.objects.get(student=student)

        #บันทึกหรืออัปเดต ChallengeDetail โดยอ้างอิง progress
        detail, created = ChallengeDetail.objects.get_or_create(
            progress=progress,
            praposition=praposition,
            defaults={'solved': solved}
        )

        already_solved = detail.solved  # เก็บสถานะก่อนอัปเดต

        if not created:
            if not detail.solved and solved:
                detail.solved = True
            detail.timestamp = timezone.now()
            detail.save()

        #เพิ่มคะแนนถ้าเพิ่งทำโจทย์นี้ถูกครั้งแรก
        if solved and (created or not already_solved):
            progress.score += score_per_question
            progress.save()

        #ตรวจสอบและอัปเดต current_difficulty
        def update_current_difficulty():
            """ฟังก์ชันตรวจสอบและอัปเดตระดับความยากปัจจุบัน"""
            # นับจำนวนโจทย์ที่ทำแล้วในแต่ละระดับ
            easy_solved_count = ChallengeDetail.objects.filter(
                progress=progress,
                praposition__difficulty='easy',
                praposition__status='challenge',
                solved=True
            ).count()

            medium_solved_count = ChallengeDetail.objects.filter(
                progress=progress,
                praposition__difficulty='medium',
                praposition__status='challenge',
                solved=True
            ).count()

            # ตรวจสอบการปลดล็อกจาก Easy ไป Medium
            if (progress.current_difficulty == 'easy' and
                easy_solved_count >= challenge_condition.easy_required_to_unlock_normal):
                progress.current_difficulty = 'medium'
                progress.save()
                print(f"🔓 อัปเดตระดับเป็น Medium: ทำโจทย์ easy แล้ว {easy_solved_count}/{challenge_condition.easy_required_to_unlock_normal}")
            # ตรวจสอบการปลดล็อกจาก Medium ไป Hard
            elif (progress.current_difficulty == 'medium' and
                  medium_solved_count >= challenge_condition.normal_required_to_unlock_hard):
                progress.current_difficulty = 'hard'
                progress.save()
                print(f"🔓 อัปเดตระดับเป็น Hard: ทำโจทย์ medium แล้ว {medium_solved_count}/{challenge_condition.normal_required_to_unlock_hard}")

        # เรียกใช้ฟังก์ชันอัปเดตระดับความยาก
        update_current_difficulty()

        #หาคะแนนเต็มเพื่อตรวจสอบว่านักศึกษาผ่านโหมดเก็บคะแนนแล้ว
        easy_count = Prapositions.objects.filter(teacher=teacher, difficulty='easy', status='challenge').count()
        medium_count = Prapositions.objects.filter(teacher=teacher, difficulty='medium', status='challenge').count()
        hard_count = Prapositions.objects.filter(teacher=teacher, difficulty='hard', status='challenge').count()
        easy_score = easy_count * challenge_condition.easy_score_per_question
        medium_score = medium_count * challenge_condition.normal_score_per_question
        hard_score = hard_count * challenge_condition.hard_score_per_question

        full_score = (easy_score + medium_score + hard_score)

        if progress.score >= (full_score*0.5):
            progress.status = True
            progress.save()

        return JsonResponse({
            'success': True,
            'total_score': total_score,
            'total_questions': total_questions,
            'score_percentage': round(score_percentage, 2),
            'answer_details': answer_details,
            'current_difficulty': progress.current_difficulty,
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

def home_view(request):
    return render(request,'app_students/std_home.html')

def change_password(request):
    if 'user_id' not in request.session:
        return redirect('login')

    student_id = request.session.get('user_id')
    student = get_object_or_404(Students, id=student_id)

    if request.method == 'POST':
        current = request.POST['current_password']
        new = request.POST['new_password']
        confirm = request.POST['confirm_password']

        # เปรียบเทียบรหัสผ่านเดิมตรง ๆ (เพราะไม่ได้ใช้ระบบ hash)
        if current != student.password:
            messages.error(request, 'รหัสผ่านเดิมไม่ถูกต้อง')
        elif new != confirm:
            messages.error(request, 'รหัสผ่านใหม่ไม่ตรงกัน')
        else:
            student.password = new  # ตั้งรหัสผ่านใหม่ตรง ๆ
            student.save()
            messages.success(request, 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว')
            # return redirect('')

    return render(request, 'app_students/manage_std.html', {'student': student})