from django.contrib import admin
from app_teachers.models import Teachers
from app_teachers.models import Prapositions
# Register your models here.
admin.site.register(Teachers)
admin.site.register(Prapositions)