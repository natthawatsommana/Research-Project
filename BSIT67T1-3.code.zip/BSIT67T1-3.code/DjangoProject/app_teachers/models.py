from django.db import models

class Teachers(models.Model):
    teacher_id = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=255)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    class Meta:
        db_table = 'teachers'  # ✅ ใช้ชื่อนี้แทนชื่ออัตโนมัติ
        verbose_name = "Teacher"             # ชื่อเอกพจน์ที่แสดงใน admin
        verbose_name_plural = "Teachers"     # ชื่อพหูพจน์ที่แสดงใน admin


class Prapositions(models.Model):
    STATUS_CHOICES = [
        ('challenge', 'Challenge'),
        ('practice', 'Practice'),
    ]

    DIFFICULTY_CHOICES = [
        ('easy', 'Easy'),
        ('medium', 'Medium'),
        ('hard', 'Hard'),
    ]

    difficulty = models.CharField(max_length=50, choices=DIFFICULTY_CHOICES)
    praposition = models.TextField()
    teacher = models.ForeignKey(Teachers, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)

    def __str__(self):
        return f"{self.praposition} สร้างโดยอาจารย์ : {self.teacher}"
    class Meta:
        db_table = 'prapositions'  # ✅ ใช้ชื่อนี้แทนชื่ออัตโนมัติ
        verbose_name = "Praposition"             # ชื่อเอกพจน์ที่แสดงใน admin
        verbose_name_plural = "Prapositions"     # ชื่อพหูพจน์ที่แสดงใน admin

class ChallengeCondition(models.Model):
    # คะแนนที่ได้ต่อข้อในแต่ละระดับ
    easy_score_per_question = models.IntegerField(default=1)
    normal_score_per_question = models.IntegerField(default=1)
    hard_score_per_question = models.IntegerField(default=1)

    # จำนวนข้อที่ต้องผ่านเพื่อปลดล็อกระดับถัดไป
    easy_required_to_unlock_normal = models.IntegerField(default=0)
    normal_required_to_unlock_hard = models.IntegerField(default=0)
    created_by = models.ForeignKey(Teachers, on_delete=models.CASCADE)  # กำหนดว่าใครสร้าง

    class Meta:
        db_table = 'ChallengeCondition'  # ✅ ใช้ชื่อนี้แทนชื่ออัตโนมัติ