from django.urls import path
from . import views
from . import views_login

urlpatterns = [
    path('login/', views_login.login_view, name='login'),
    path('logout/', views_login.logout_view, name='logout'),
    path('', views.home, name='home'),
    path('add-student', views.add_student, name='add_student'),
    path('truth-table/<int:praposition_id>/', views.truth_table_view, name='truth_table'),
    path('submit-answer/<int:praposition_id>/', views.submit_answer, name='submit_answer'),
    path('T_dashboard', views.T_dashboard, name='T_dashboard'),
    path('generate-equation/', views.generate_equation_view, name='generate_equation'),
    path('create-praposition-from-popup/', views.create_praposition_from_popup, name='create_praposition_from_popup'),
    path('save-challenge-condition/', views.save_challenge_condition, name='save_challenge_condition'),
    path('P_dashboard', views.P_dashboard, name='P_dashboard'),
    path('score',views.score_view,name='score'),
    path('export_scores/', views.export_scores, name='export_scores'),
    path('edit-praposition/', views.edit_praposition, name='edit_praposition'),
    path('upload-students/', views.upload_students_from_csv, name='upload_students'),
    path('edit-student/', views.edit_student, name='edit_student'),
    path('change_password/', views.change_teacher_password, name='change_teacher_password')
]