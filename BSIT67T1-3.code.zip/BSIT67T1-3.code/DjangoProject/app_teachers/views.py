import os
import re
from django.shortcuts import render, redirect, get_object_or_404
from django.http.response import HttpResponse
from app_teachers.models import Teachers
from app_students.models import Students,ChallengeProgress,ChallengeDetail
from app_teachers.models import ChallengeCondition
from django.contrib import messages
from core.logic.truth_table import generate_truth_table_data
from core.logic.utils import generate_equation
from .models import Prapositions, Teachers
from django.http import Http404, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
import pandas as pd
from django.db import IntegrityError, transaction
from django.db.models import Q

# Create your views here.

def account(request):
    return render(request, 'app_teachers/account.html')

def edit_student(request):
    if request.method == 'POST':
        student_db_id = request.POST.get('student_db_id')
        student_id = request.POST.get('student_id').strip()
        first_name = request.POST.get('first_name').strip()
        last_name = request.POST.get('last_name').strip()
        password = request.POST.get('password').strip()

        try:
            student = Students.objects.get(id=student_db_id)

            # ตรวจสอบว่ารหัสนักศึกษาซ้ำกับคนอื่นหรือไม่
            if Students.objects.filter(student_id=student_id).exclude(id=student_db_id).exists():
                messages.error(request, f"ไม่สามารถบันทึกได้: รหัสนักศึกษา {student_id} ถูกใช้แล้ว")
                return redirect('T_dashboard')

            # ถ้าแก้ student_id ให้ใช้รหัสใหม่เป็น password ด้วย
            if student.student_id != student_id:
                student.password = student_id

            # อัปเดตข้อมูล
            student.student_id = student_id
            student.first_name = first_name
            student.last_name = last_name
            student.save()

            messages.success(request, "แก้ไขข้อมูลนักศึกษาเรียบร้อยแล้ว")
        except Students.DoesNotExist:
            messages.error(request, "ไม่พบนักศึกษาในระบบ")

    return redirect('T_dashboard')

def add_student(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        student_id = request.POST.get('student_id', '').strip()
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        password = request.POST.get('password', '').strip()

        if Students.objects.filter(student_id=student_id).exists():
            messages.error(request, f"ไม่สามารถเพิ่มนักศึกษาได้: รหัส {student_id} มีอยู่ในระบบแล้ว")
            return redirect('T_dashboard')

        try:
            Students.objects.create(
                student_id=student_id,
                first_name=first_name,
                last_name=last_name,
                password=password,
                teacher=teacher
            )
            messages.success(request, f"เพิ่มนักศึกษา {first_name} {last_name} สำเร็จแล้ว")
        except IntegrityError as e:
            messages.error(request, f"เกิดข้อผิดพลาดในการบันทึกข้อมูล: {str(e)}")

        return redirect('T_dashboard')

    return redirect('T_dashboard')

def home(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    return render(request, 'app_teachers/P_dashboard.html', {
        'teacher': teacher
    })

def save_challenge_condition(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        easy_score = int(request.POST['easy_score'])
        normal_score = int(request.POST['normal_score'])
        hard_score = int(request.POST['hard_score'])
        easy_to_normal = int(request.POST['easy_to_normal'])
        normal_to_hard = int(request.POST['normal_to_hard'])

        easy_count = Prapositions.objects.filter(
            teacher=teacher, difficulty='easy', status='challenge'
        ).count()

        normal_count = Prapositions.objects.filter(
            teacher=teacher, difficulty='medium', status='challenge'
        ).count()

        if easy_to_normal > easy_count:
            messages.error(request, f"คุณใส่จำนวนข้อผ่านระดับง่ายมากกว่าที่มีอยู่ ({easy_count} ข้อ)")
            return redirect('P_dashboard')

        if normal_to_hard > normal_count:
            messages.error(request, f"คุณใส่จำนวนข้อผ่านระดับปานกลางมากกว่าที่มีอยู่ ({normal_count} ข้อ)")
            return redirect('P_dashboard')

        with transaction.atomic():  # ✅ เพื่อความปลอดภัยของฐานข้อมูล
            # ✅ บันทึกหรืออัปเดต ChallengeCondition
            existing = ChallengeCondition.objects.filter(created_by=teacher).first()
            if existing:
                existing.easy_score_per_question = easy_score
                existing.normal_score_per_question = normal_score
                existing.hard_score_per_question = hard_score
                existing.easy_required_to_unlock_normal = easy_to_normal
                existing.normal_required_to_unlock_hard = normal_to_hard
                existing.save()
            else:
                ChallengeCondition.objects.create(
                    easy_score_per_question=easy_score,
                    normal_score_per_question=normal_score,
                    hard_score_per_question=hard_score,
                    easy_required_to_unlock_normal=easy_to_normal,
                    normal_required_to_unlock_hard=normal_to_hard,
                    created_by=teacher
                )

            # ✅ รีเซ็ต progress และลบ detail ของนักเรียนที่สังกัดอาจารย์นี้
            students = Students.objects.filter(teacher=teacher)
            progresses = ChallengeProgress.objects.filter(student__in=students)

            ChallengeDetail.objects.filter(progress__in=progresses).delete()  # ลบ detail
            progresses.update(score=0,current_difficulty = 'easy', status=False)  # รีเซ็ตคะแนนและสถานะ
            
        messages.success(request, "บันทึกเงื่อนไขสำเร็จ (และรีเซ็ตข้อมูลนักเรียนเรียบร้อยแล้ว)")
        return redirect('P_dashboard')

def T_dashboard(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        # เช็คว่ามีการ submit ฟอร์มหรือไม่ (ป้องกันสับสนกับปุ่มลบ)
        if 'student_id' in request.POST:
            student_id = request.POST.get('student_id')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            password = request.POST.get('password')

            # ป้องกันรหัสซ้ำ
            if Students.objects.filter(student_id=student_id, teacher=teacher).exists():
                # กรณีรหัสซ้ำ - ส่งข้อความแจ้งเตือนไปแสดงใน template ถ้าต้องการ
                students = Students.objects.filter(teacher=teacher)
                return render(request, 'app_teachers/T_dashboard.html', {
                    'teacher': teacher,
                    'students': students,
                    'error_message': 'รหัสนักศึกษานี้มีอยู่แล้ว'
                })

            # สร้างนักศึกษาใหม่
            Students.objects.create(
                student_id=student_id,
                first_name=first_name,
                last_name=last_name,
                password=password, 
                teacher=teacher
            )
            return redirect('T_dashboard')

        # ลบตามเดิม
        elif 'delete_selected' in request.POST:
            ids_to_delete = request.POST.getlist('selected_students')
            Students.objects.filter(id__in=ids_to_delete, teacher=teacher).delete()

        elif 'delete_all' in request.POST:
            Students.objects.filter(teacher=teacher).delete()

        return redirect('T_dashboard')

    students = Students.objects.filter(teacher=teacher).order_by('student_id')
    return render(request, 'app_teachers/T_dashboard.html', {
        'teacher': teacher,
        'students': students,
        'message': messages.get_messages(request)
    })

def create_praposition_from_popup(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('teacher_login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        difficulty = request.POST.get('difficultyPopup')
        raw_praposition = request.POST.get('prapositionManual') or request.POST.get('prapositionPopup')
        status = request.POST.get('statusPopup')

        def normalize_symbols(expr):
            replacements = [
                (r'->', '→'),
                (r'\^', '∧'),
                (r'v', '∨'),
                (r'V', '∨'),
                (r'~', '¬'),
                (r'=', '↔')
            ]
            for pattern, repl in replacements:
                expr = re.sub(pattern, repl, expr)
            return expr

        praposition = normalize_symbols(raw_praposition)

        # ตรวจสอบซ้ำ
        if status == "both":
            duplicates = Prapositions.objects.filter(
                praposition=praposition,
                teacher=teacher
            ).filter(Q(status='practice') | Q(status='challenge'))

            if duplicates.exists():
                messages.error(request, "มีประพจน์นี้อยู่แล้วในโหมด Practice หรือ Challenge")
                return redirect('P_dashboard')

            for s in ["practice", "challenge"]:
                Prapositions.objects.create(
                    difficulty=difficulty,
                    praposition=praposition,
                    status=s,
                    teacher=teacher
                )
        else:
            duplicate = Prapositions.objects.filter(
                praposition=praposition,
                status=status,
                teacher=teacher
            ).first()

            if duplicate:
                messages.error(request, f"มีประพจน์นี้อยู่แล้วในโหมด {status.capitalize()}")
                return redirect('P_dashboard')

            Prapositions.objects.create(
                difficulty=difficulty,
                praposition=praposition,
                status=status,
                teacher=teacher
            )

        messages.success(request, "บันทึกประพจน์เรียบร้อยแล้ว")

    return redirect('P_dashboard')

def P_dashboard(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        if 'delete_all' in request.POST:
            if request.POST.get('really_delete_all') == 'true':
            # ✅ ลบโจทย์ทั้งหมดของอาจารย์ ไม่สน filter
                Prapositions.objects.filter(teacher=teacher).delete()
            else:
                filtered_qs = Prapositions.objects.filter(teacher=teacher)
                difficulty = request.GET.get('difficulty')
                status = request.GET.get('status')

                if difficulty and difficulty != 'all':
                    filtered_qs = filtered_qs.filter(difficulty=difficulty)
                if status and status != 'all':
                    filtered_qs = filtered_qs.filter(status=status)
                filtered_qs.delete()
        else:
            ids = request.POST.getlist('selected_praposition')
            Prapositions.objects.filter(id__in=ids, teacher=teacher).delete()
        return redirect('P_dashboard')

    # ดึงจำนวนนักเรียนทั้งหมด
    student_count = Students.objects.filter(teacher=teacher).count()

    # ดึงจำนวนโจทย์ตรรกศาสตร์ทั้งหมด
    total_propositions = Prapositions.objects.filter(teacher=teacher).count()

    # ดึงจำนวนโจทย์ในโหมดเก็บคะแนน
    total_challenge = Prapositions.objects.filter(teacher=teacher, status='challenge').count()

    # ดึงจำนวนโจทย์ในโหมดฝึกซ้อม
    total_practice = Prapositions.objects.filter(teacher=teacher, status='practice').count()

    # Filters
    difficulty = request.GET.get('difficulty')
    status = request.GET.get('status')  # ใช้ status ตรงกับ model

    praposition_list = Prapositions.objects.filter(teacher=teacher)
    if difficulty:
        praposition_list = praposition_list.filter(difficulty=difficulty)
    if status:
        praposition_list = praposition_list.filter(status=status)

    # praposition_list = praposition_list.order_by('-id')
    difficulty_order = {'easy': 1, 'medium': 2, 'hard': 3}
    praposition_list = sorted(
    praposition_list,
    key=lambda x: (difficulty_order.get(x.difficulty, 4), -x.id)
    )

    # ดึง ChallengeCondition ถ้ามี
    condition = ChallengeCondition.objects.filter(created_by=teacher).first()
    
    # ดึงจำนวนโจทย์ที่มีอยู่
    easy_count = Prapositions.objects.filter(teacher=teacher, difficulty='easy', status='challenge').count()
    normal_count = Prapositions.objects.filter(teacher=teacher, difficulty='medium', status='challenge').count()
    
    paginator = Paginator(praposition_list, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'app_teachers/P_dashboard.html', {
        'praposition_list': praposition_list,
        'teacher': teacher,
        'student_count': student_count,
        'total_propositions': total_propositions,
        'total_challenge': total_challenge,
        'total_practice': total_practice,
        'condition': condition,
        'easy_count': easy_count,
        'normal_count': normal_count,
        'praposition_list': page_obj,
    })

def edit_praposition(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        praposition_id = request.POST.get('id')  # <-- ✅ ดึงจากฟอร์ม
        praposition_obj = get_object_or_404(Prapositions, id=praposition_id, teacher=teacher)

        raw_praposition = request.POST.get('praposition')
        difficulty = request.POST.get('difficulty')
        status = request.POST.get('status')

        # Normalize
        def normalize_symbols(expr):
            replacements = [
                (r'->', '→'),
                (r'\^', '∧'),
                (r'v', '∨'),
                (r'V', '∨'),
                (r'=', '↔'),
                (r'~', '¬'),
            ]
            for pattern, repl in replacements:
                expr = re.sub(pattern, repl, expr)
            return expr

        normalized_praposition = normalize_symbols(raw_praposition)

        if status == "both":
            duplicates = Prapositions.objects.filter(
                praposition=normalized_praposition,
                teacher=teacher
            ).exclude(id=praposition_obj.id).filter(
                Q(status='practice') | Q(status='challenge')
            )

            if duplicates.exists():
                messages.error(request, "มีประพจน์นี้อยู่แล้วในโหมด Practice หรือ Challenge")
                return redirect('P_dashboard')

            praposition_obj.delete()

            for s in ["practice", "challenge"]:
                Prapositions.objects.create(
                    praposition=normalized_praposition,
                    difficulty=difficulty,
                    status=s,
                    teacher=teacher
                )

            messages.success(request, "แก้ไขประพจน์เรียบร้อยแล้วในโหมด Practice และ Challenge")

        else:
            duplicate = Prapositions.objects.filter(
                praposition=normalized_praposition,
                status=status,
                teacher=teacher
            ).exclude(id=praposition_obj.id).first()

            if duplicate:
                messages.error(request, f"มีประพจน์นี้อยู่แล้วในโหมด {status.capitalize()}")
                return redirect('P_dashboard')

            praposition_obj.praposition = normalized_praposition
            praposition_obj.difficulty = difficulty
            praposition_obj.status = status
            praposition_obj.save()

            messages.success(request, "แก้ไขประพจน์เรียบร้อยแล้ว")

        return redirect('P_dashboard')

    # ถ้าไม่ใช่ POST —> ไม่รองรับ
    return redirect('P_dashboard')

def generate_equation_view(request):
    try:
        difficulty_str = request.GET.get('difficulty', 'easy')

        # แปลงระดับความยากจาก string เป็นตัวเลข
        difficulty_map = {
            'easy': 1,
            'medium': 2,
            'hard': 3
        }

        if difficulty_str not in difficulty_map:
            return JsonResponse({'error': 'Invalid difficulty value'}, status=400)

        difficulty_level = difficulty_map[difficulty_str]
        equation = generate_equation(difficulty_level)
        return JsonResponse({'equation': equation})

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

def truth_table_view(request, praposition_id):

    praposition = get_object_or_404(Prapositions, id=praposition_id)

    # เรียกใช้ฟังก์ชันและเก็บค่าไว้ใน result
    result = generate_truth_table_data(praposition.praposition)

    # ดึงข้อมูลจาก dict ที่รีเทิร์นมา
    equation = result['equation']
    test_data = result['test_data']
    correct_data = result['correct_data']
    # บันทึกเข้า session
    if 'truth_table_data' not in request.session:
        request.session['truth_table_data'] = {}

    request.session['truth_table_data'][str(praposition_id)] = {
        'test_data': test_data,
        'correct_data': correct_data
    }
    request.session.modified = True
    # ส่งไปยัง template
    return render(request, 'app_teachers/truth_table.html', {
        'equation': equation,
        'test_data': test_data,
        'correct_data': correct_data,
        'praposition_id': praposition_id
    })

@csrf_exempt
def submit_answer(request, praposition_id):
    if request.method == 'POST':
        try:
            # รับข้อมูลจาก AJAX
            data = json.loads(request.body)
            student_answers = data.get('answers', [])
            
            # ดึงข้อมูลจาก session หรือสร้างใหม่
            if 'truth_table_data' not in request.session or str(praposition_id) not in request.session['truth_table_data']:
                return JsonResponse({
                    'success': False,
                    'error': 'ไม่พบข้อมูลตาราง กรุณาโหลดหน้าใหม่'
                })
            
            # ดึงข้อมูลจาก session
            session_data = request.session['truth_table_data'][str(praposition_id)]
            test_data = session_data['test_data']
            correct_data = session_data['correct_data']
            
            # ตรวจสอบคำตอบและให้คะแนน
            total_score = 0
            total_questions = 0
            answer_details = []
            
            # สร้าง mapping ของคำตอบนักเรียน
            student_answer_map = {}
            for answer in student_answers:
                key = f"{answer['row']}-{answer['col']}"
                student_answer_map[key] = answer['value']
            
            print("Debug - Student answer map:", student_answer_map)
            print("Debug - Test data structure:")
            for i, row in enumerate(test_data):
                print(f"  Row {i}: {row}")
            print("Debug - Correct data structure:")
            for i, row in enumerate(correct_data):
                print(f"  Row {i}: {row}")
            
            for row_idx, row in enumerate(test_data):
                for col_idx, cell in enumerate(row):
                    if cell == "___":  # ช่องที่ต้องตอบ
                        total_questions += 1
                        
                        # หาคำตอบของนักเรียน
                        key = f"{row_idx}-{col_idx}"
                        student_answer = student_answer_map.get(key, "")
                        
                        # เปรียบเทียบกับเฉลย
                        correct_answer = correct_data[row_idx][col_idx]
                        is_correct = student_answer == correct_answer
                        
                        print(f"Debug - Position [{row_idx}][{col_idx}]: Student='{student_answer}', Correct='{correct_answer}', Match={is_correct}")
                        
                        if is_correct:
                            total_score += 1
                        
                        answer_details.append({
                            'row': row_idx,
                            'col': col_idx,
                            'student_answer': student_answer,
                            'correct_answer': correct_answer,
                            'is_correct': is_correct
                        })
            
            # คำนวณคะแนนเป็นเปอร์เซ็นต์
            score_percentage = (total_score / total_questions * 100) if total_questions > 0 else 0
            
            print(f"Debug - Final score: {total_score}/{total_questions} = {score_percentage}%")
            
            return JsonResponse({
                'success': True,
                'total_score': total_score,
                'total_questions': total_questions,
                'score_percentage': round(score_percentage, 2),
                'answer_details': answer_details
            })
            
        except Exception as e:
            print(f"Debug - Error: {str(e)}")
            import traceback
            traceback.print_exc()
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

def score_view(request):
    teacher_id = request.session.get('user_id')  # ✅ ใช้ key 'user_id'
    if not teacher_id:
        return redirect('login')

    teacher = Teachers.objects.get(id=teacher_id)  # ✅ ค้นด้วย id (int)
    progress_list = ChallengeProgress.objects.filter(
        student__teacher=teacher
    ).select_related('student').order_by('student__student_id')
    
    paginator = Paginator(progress_list, 10)  # แสดง 10 รายการต่อหน้า
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'app_teachers\score.html', {'page_obj': page_obj})



def export_scores(request):
    teacher_id = request.session.get('user_id')  # ✅ ใช้ key 'user_id'
    if not teacher_id:
        return redirect('login')

    teacher = Teachers.objects.get(id=teacher_id)
    progresses = ChallengeProgress.objects.filter(student__teacher=teacher).select_related('student')

    data = []
    for p in progresses:
        data.append({
            'รหัสนักเรียน': p.student.student_id,
            'ชื่อ': f"{p.student.first_name}",
            'คะแนน': p.score,
            'สถานะ': 'ดีมาก' if p.status 
            else 'ควรปรับปรุง',
        })

    df = pd.DataFrame(data)

    # สร้างไฟล์ Excel แบบ Response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=student_scores.xlsx'

    with pd.ExcelWriter(response, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='คะแนนนักเรียน')

    return response

def upload_students_from_csv(request):
    teacher_id = request.session.get('user_id')
    if not teacher_id:
        return redirect('login')

    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        if not request.FILES.get('csv_file'):
            messages.error(request, 'กรุณาเลือกไฟล์ CSV ก่อนทำการอัปโหลด')
            return redirect('T_dashboard')

        try:
            df = pd.read_csv(request.FILES['csv_file'], header=None)
        except Exception as e:
            messages.error(request, f'ไม่สามารถอ่านไฟล์ CSV ได้: {e}')
            return redirect('T_dashboard')

        # หาตำแหน่งแถวที่มีคำว่า "รหัสประจำตัว"
        data_start_idx = None
        for i in range(len(df)):
            if df.iloc[i].astype(str).str.contains("รหัสประจำตัว").any():
                data_start_idx = i + 1
                break

        if data_start_idx is None:
            messages.error(request, 'ไม่พบหัวตาราง "รหัสประจำตัว" ในไฟล์ CSV')
            return redirect('T_dashboard')

        data = df.iloc[data_start_idx:].reset_index(drop=True)
        created_count = 0
        duplicate_ids = []

        for idx, row in data.iterrows():
            try:
                student_id = str(row[1]).strip()
                full_name = str(row[3]).strip()

                if not student_id.isdigit() or full_name.lower() in ('nan', '', 'none'):
                    continue

                # เช็กรหัสซ้ำในระบบ
                if Students.objects.filter(student_id=student_id).exists():
                    duplicate_ids.append(student_id)
                    continue

                # แยกชื่อและนามสกุล
                name_parts = full_name.split()
                if len(name_parts) == 1:
                    first_name = name_parts[0]
                    last_name = ''
                else:
                    first_name = name_parts[0]
                    last_name = ' '.join(name_parts[1:])

                Students.objects.create(
                    student_id=student_id,
                    first_name=first_name,
                    last_name=last_name,
                    password=student_id,
                    teacher=teacher
                )
                created_count += 1
            except Exception as e:
                print(f"ERROR while processing row {idx}: {row} -> {e}")
                continue

        if created_count > 0:
            messages.success(request, f"สร้างบัญชีนักศึกษา {created_count} รายการเรียบร้อยแล้ว")
        if duplicate_ids:
            messages.warning(request, f"รหัสนักศึกษาต่อไปนี้มีอยู่แล้วในระบบ และไม่ถูกเพิ่ม: {', '.join(duplicate_ids)}")

        return redirect('T_dashboard')

    return redirect('T_dashboard')

# def upload_students_from_csv(request):
#     teacher_id = request.session.get('user_id')
#     if not teacher_id:
#         return redirect('login')

#     teacher = Teachers.objects.get(id=teacher_id)

#     if request.method == 'POST':
#         if not request.FILES.get('csv_file'):
#             messages.error(request, 'กรุณาเลือกไฟล์ CSV ก่อนทำการอัปโหลด')
#             return redirect('T_dashboard')

#         try:
#             df = pd.read_csv(request.FILES['csv_file'], header=None)
#         except Exception as e:
#             messages.error(request, f'ไม่สามารถอ่านไฟล์ CSV ได้: {e}')
#             return redirect('T_dashboard')

#         # หาตำแหน่งแถวที่มีคำว่า "รหัสประจำตัว"
#         data_start_idx = None
#         for i in range(len(df)):
#             if df.iloc[i].astype(str).str.contains("รหัสประจำตัว").any():
#                 data_start_idx = i + 1
#                 break

#         if data_start_idx is None:
#             messages.error(request, 'ไม่พบหัวตาราง "รหัสประจำตัว" ในไฟล์ CSV')
#             return redirect('T_dashboard')

#         data = df.iloc[data_start_idx:].reset_index(drop=True)
#         created_count = 0

#         for idx, row in data.iterrows():
#             try:
#                 student_id = str(row[1]).strip()
#                 full_name = str(row[3]).strip()

#                 if not student_id.isdigit() or full_name.lower() in ('nan', '', 'none'):
#                     continue

#                 # แยกชื่อและนามสกุล
#                 name_parts = full_name.split()
#                 if len(name_parts) == 1:
#                     first_name = name_parts[0]
#                     last_name = ''
#                 else:
#                     first_name = name_parts[0]
#                     last_name = ' '.join(name_parts[1:])  # รองรับกรณีนามสกุลหลายคำ

#                 _, created = Students.objects.get_or_create(
#                     student_id=student_id,
#                     defaults={
#                         'first_name': first_name,
#                         'last_name': last_name,
#                         'password': student_id,
#                         'teacher': teacher
#                     }
#                 )
#                 if created:
#                     created_count += 1
#             except Exception as e:
#                 print(f"ERROR while processing row {idx}: {row} -> {e}")
#                 continue

#         messages.success(request, f"สร้างบัญชีนักศึกษา {created_count} รายการเรียบร้อยแล้ว")
#         return redirect('T_dashboard')

#     return redirect('T_dashboard')

def change_teacher_password(request):
    if request.session.get('user_role') != 'teacher':
        return redirect('teacher_login')

    teacher_id = request.session.get('user_id')
    teacher = Teachers.objects.get(id=teacher_id)

    if request.method == 'POST':
        current_pw = request.POST.get('current_password')
        new_pw = request.POST.get('new_password')
        confirm_pw = request.POST.get('confirm_password')

        # ตรวจสอบรหัสผ่านเดิม
        if teacher.password != current_pw:
            messages.error(request, "รหัสผ่านเดิมไม่ถูกต้อง")
            return redirect('change_teacher_password')

        if new_pw != confirm_pw:
            messages.error(request, "รหัสผ่านใหม่ไม่ตรงกัน")
            return redirect('change_teacher_password')

        if len(new_pw) < 6:
            messages.error(request, "รหัสผ่านใหม่ควรมีอย่างน้อย 6 ตัวอักษร")
            return redirect('change_teacher_password')

        # อัปเดตรหัสผ่าน
        teacher.password = new_pw
        teacher.save()

        messages.success(request, "เปลี่ยนรหัสผ่านเรียบร้อยแล้ว")
        return redirect('P_dashboard')

    return render(request, 'app_teachers/change_password.html')