
from django.shortcuts import render, redirect
from django.http import HttpResponse
from app_students.models import Students
from app_teachers.models import Teachers
from app_teachers.form import LoginForm

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # ตรวจสอบกับ Students
            try:
                student = Students.objects.get(student_id=username, password=password)
                request.session['user_role'] = 'student'
                request.session['user_id'] = student.id
                return redirect('students')
            except Students.DoesNotExist:
                pass

            # ตรวจสอบกับ Teachers
            try:
                teacher = Teachers.objects.get(teacher_id=username, password=password)
                request.session['user_role'] = 'teacher'
                request.session['user_id'] = teacher.id
                return redirect('P_dashboard')
            except Teachers.DoesNotExist:
                pass

            form.add_error(None, 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง')
    else:
        form = LoginForm()

    return render(request, 'app_teachers/login.html', {'form': form})

def logout_view(request):
    request.session.flush()
    return redirect('login')