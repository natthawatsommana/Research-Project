import itertools
from django.shortcuts import get_object_or_404
from .utils import *
from mathesis.grammars import BasicGrammar
from mathesis.semantics.truth_table import ClassicalTruthTable

def generate_truth_table_data(equation: str) -> dict:
    columns = create_columns(equation)
    # หาตัวแปรพื้นฐานจาก columns
    base_vars = sorted({c for col in columns for c in col if c.isalpha() and len(c) == 1})

    # สร้างแถวค่าความจริง
    rows = []
    for combo in itertools.product(['0', '1'], repeat=len(base_vars)):
        values = dict(zip(base_vars, combo))
        row = []
        for col in columns:
            if col in values:
                row.append(values[col])
            else:
                row.append(eval_expr(col, values))
        rows.append(row)
        
    random.shuffle(rows)
    # รวม header และ rows กลับเข้าด้วยกัน
    correct_truth_table = [columns] + rows

    # รวม columns และ rows เข้าด้วยกัน
    truth_table = copy.deepcopy(correct_truth_table)

    for i in range(len(rows)):
        row_index = i # แถวที่ 1 (เริ่มจาก 0)
        for praposition in reversed(columns):
            # ดึงข้อมูลแต่ละคอลัมน์
            last_item = praposition
            # แยกประพจน์และเครื่องหมาย
            result = process_expression(last_item)

            # ถ้ามีผลลัพธ์ ให้นำไปใช้ต่อ
            if(is_basic_expression(last_item)):
                left_expr = ''
                operator = ''
                right_expr = ''
            else:
                if result:
                    left_expr, operator, right_expr = result

                    # หาตำแหน่งของคอลัมน์ ประพจน์ที่ถูกแยก ใน columns
                    left_index = columns.index(left_expr)  # หาตำแหน่งของคอลัมน์ 'left_expr'
                    right_index = columns.index(right_expr)  # หาตำแหน่งของคอลัมน์ 'right_expr'

                    # ดึงค่าจากแถว
                    left_value = correct_truth_table[row_index + 1][left_index]  # +1 เพราะแถวแรกเป็น columns
                    right_value = correct_truth_table[row_index + 1][right_index]  # +1 เพราะแถวแรกเป็น columns

            # การลบ
            truth_table = process_operator1(operator, left_value, right_value, left_expr, right_expr, last_item, correct_truth_table, truth_table, row_index, columns, left_index, right_index)
        delete_random_column(truth_table, row_index, columns)

    update_truth_table(truth_table, correct_truth_table)

    truth_table  = [replace_values(row) for row in truth_table]

    correct_truth_table = [replace_values(row) for row in correct_truth_table]

    #ตรวจสอบประพจน์อีกรอบเพื่อทำการลบให้มีประสิทธิภาพมากยิ่งขึ้น
    checkPQR(truth_table, correct_truth_table,columns,rows)

    update_truth_table(truth_table, correct_truth_table)

    truth_table  = [replace_values(row) for row in truth_table]

    #หาคำตอบประพจน์ทุกคอลัมน์ ถ้าหาไม่ได้แถวนั้นจะมี ? อยู่
    result = solve_truth_table(truth_table)

    #ถ้าแถวใดมี ? แสดงว่าไม่สามารถหาคำตอบได้ จะทำการเปลี่ยนการเฉลยของแถวดังกล่าวเพื่อให้สามารถหาคำตอบได้ทุกแถว
    final_truth_table = replace_question_rows(result, truth_table, correct_truth_table)
    final_truth_table = [replace_values(row) for row in final_truth_table]

    return {
        "equation": equation,
        "test_data": final_truth_table,
        "correct_data": correct_truth_table
    }