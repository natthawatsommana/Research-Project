import re
import random
import copy
from typing import OrderedDict
import itertools
import pandas as pd
from collections import defaultdict

    #สุ่มระดับของสมการ 1 2 3
def random_type():
    random_number = random.randint(1, 3)
    return random_number
    
    #เอาไว้กันกรณี Pv¬P ซึ่งทำให้สมการดูสับสน
def negate_expression(expr):
    """แปลงนิพจน์เป็นนิเสธนิพจน์ หรือกลับจากนิเสธนิพจน์เป็นนิพจน์ปกติ"""
    if expr.startswith('¬'):
        return expr[1:]  # เอา "¬" ออก
    else:
        return '¬' + expr  # เติม "¬" เข้าไป

    #สุ่มสมการ
def random_equation():
    # รายการนิพจน์และตัวดำเนินการ
    expressions = ['P', 'Q', 'R', '¬P', '¬Q', '¬R']
    operators = ['→', '∧', '∨']
    while True:
        # สุ่มนิพจน์ตัวแรก
        expr1 = random.choice(expressions) 
        # สุ่มนิพจน์ตัวที่สอง โดยต้องไม่ซ้ำกับตัวแรกและไม่นิเสธกัน
        remaining_expressions = [
            expr for expr in expressions 
            if expr != expr1 and expr != negate_expression(expr1)
        ]  
        # ถ้าหลังกรองแล้วไม่มีนิพจน์เหลือให้ข้ามการสุ่ม
        if not remaining_expressions:
            continue      
        expr2 = random.choice(remaining_expressions)
        # สุ่มตัวดำเนินการ
        operator = random.choice(operators)
        # รวมเป็นสมการ
        equation = f"({expr1}{operator}{expr2})"
        return equation   
    #สุ่มนิพจน์
def random_expr():
    expression = ['P', 'Q', 'R', '¬P', '¬Q', '¬R']
    expr = random.choice(expression)
    return expr
    
    #สุ่มเครื่องหมาย
def random_operator():
    operators = ['→', '∧', '∨', '↔']
    operator = random.choice(operators)
    return operator

#สร้างคอลัมน์ แยกคอลัมน์ตามสมการที่ใส่เข้ามา
def create_columns(proposition):
    def extract_sub_expressions_in_order(expr):
        stack = []
        spans = []
        result = []
        seen = set()

        for i, c in enumerate(expr):
            if c == '(':
                stack.append(i)
            elif c == ')':
                if stack:
                    start = stack.pop()
                    end = i

                    # ดึง prefix '¬' ถ้ามี
                    prefix_start = start - 1
                    while prefix_start >= 0 and expr[prefix_start] == '¬':
                        prefix_start -= 1
                    prefix_start += 1

                    full_expr = expr[prefix_start:end + 1]
                    inner_expr = expr[start + 1:end]

                    for sub in [inner_expr, full_expr]:
                        clean = sub.strip('()')
                        if clean not in seen:
                            seen.add(clean)
                            result.append(sub)

        return result

    # ดึงตัวแปร
    base_vars = sorted(set(re.findall(r'\b[a-zA-Z]\b', proposition)))

    # ดึง ¬ ตัวแปร
    not_exprs = []
    for match in re.finditer(r'¬[a-zA-Z]', proposition):
        literal = match.group()
        if literal not in not_exprs:
            not_exprs.append(literal)

    # ดึง sub-expressions ตามลำดับที่พบ
    sub_exprs_in_order = extract_sub_expressions_in_order(proposition)

    # กรองออก base vars กับ not_exprs
    sub_exprs_filtered = [
        e for e in sub_exprs_in_order
        if e not in base_vars and e not in not_exprs and e != proposition
    ]

    # สร้างลิสต์สุดท้าย
    columns = base_vars + not_exprs + sub_exprs_filtered + [proposition]

    # ลบซ้ำแบบ strict
    final_columns = []
    seen = set()
    for col in columns:
        if col not in seen:
            seen.add(col)
            final_columns.append(col)

    return final_columns

# ฟังก์ชัน: แปลง infix เป็น postfix
def infix_to_postfix(expr):
    output = []
    stack = []
    precedence = {
        '¬': 4,
        '∧': 3,
        '∨': 2,
        '→': 1,
        '↔': 0
    }
    tokens = tokenize(expr)
    for token in tokens:
        if token.isalpha() or token in ['0', '1']:
            output.append(token)
        elif token == '¬':
            stack.append(token)
        elif token in precedence:
            while (stack and stack[-1] != '(' and
                   precedence.get(stack[-1], 0) >= precedence[token]):
                output.append(stack.pop())
            stack.append(token)
        elif token == '(':
            stack.append(token)
        elif token == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            if stack: stack.pop()
    while stack:
        output.append(stack.pop())
    return output

# ฟังก์ชัน: แยก token เช่น P, Q, ¬, (, → ฯลฯ
def tokenize(expr):
    tokens = []
    i = 0
    while i < len(expr):
        c = expr[i]
        if c.isalpha() and len(c) == 1:  # ตัวแปร 1 ตัว เช่น A, b
            tokens.append(c)
        elif c in '¬∧∨()':
            tokens.append(c)
        elif expr[i:i+1] in {'→', '↔'}:
            tokens.append(expr[i])
        elif expr[i:i+2] in {'→', '↔'}:
            tokens.append(expr[i:i+2])
            i += 1
        elif c.isspace():
            pass  # ข้ามช่องว่าง
        elif c in '01':
            tokens.append(c)
        else:
            raise ValueError(f'Unknown character: {c}')
        i += 1
    return tokens

# ฟังก์ชัน: ประเมินค่าจาก postfix
def eval_postfix(postfix):
    stack = []
    for token in postfix:
        if token in ['0', '1']:
            stack.append(int(token))
        elif token == '¬':
            a = stack.pop()
            stack.append(int(not a))
        elif token == '∧':
            b, a = stack.pop(), stack.pop()
            stack.append(a & b)
        elif token == '∨':
            b, a = stack.pop(), stack.pop()
            stack.append(a | b)
        elif token == '→':
            b, a = stack.pop(), stack.pop()
            stack.append(int((not a) | b))
        elif token == '↔':
            b, a = stack.pop(), stack.pop()
            stack.append(int(a == b))
    return str(stack[0]) if stack else '?'

def eval_expr(expr, values):
    replaced = ''
    for c in expr:
        if c.isalpha() and c in values:
            replaced += values[c]
        else:
            replaced += c
    try:
        postfix = infix_to_postfix(replaced)
        return eval_postfix(postfix)
    except Exception:
        return '?'

#ลบตารางค่าความจริงตาม เครื่องหมาย
def process_operator1(operator, left_value, right_value, left_expr, right_expr, last_item,
                     correct_truth_table, truth_table, row_index, columns, left_index, right_index):
    def mark_delete(column_name):
        if column_name in columns:
            truth_table[row_index + 1][columns.index(column_name)] = "Delete"

    def is_last_item():
        return last_item == correct_truth_table[0][-1]

    #เทสฟังก์ชันนี้ด้วย
    def handle_basic_expression():
        # สร้างเซตตัวแปรจาก columns เช่น {"P", "Q", "R", "A", ...}
        variables = set()
        for col in columns:
            if col.startswith("¬"):
                variables.add(col[1:])  # เอาเฉพาะชื่อหลัง ¬
            else:
                variables.add(col)

        # ตรวจสอบว่า left_expr หรือ right_expr อยู่ในตัวแปรที่เราพบ
        for var in variables:
            if left_expr == var or left_expr == f"¬{var}" or right_expr == var or right_expr == f"¬{var}":
                mark_delete(var)
                mark_delete(f"¬{var}")

    def handle_expression():
        truth_table[row_index + 1][left_index] = "Delete"
        truth_table[row_index + 1][right_index] = "Delete"

    def process_disjunction():  # OR (∨)
        if left_value == "0" and right_value == "0":
            #print("Both F: 0 ∨ 0")
            if is_last_item():
                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
            else:
                #if(truth_table[row_index + 1][columns.index(last_item)] != "Delete"):
                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
            if is_basic_expression(left_expr) or is_basic_expression(right_expr):
                handle_basic_expression()
            else:
                handle_expression()
        elif left_value == "0":
            #print("Left F: 0 ∨ 1")
            #truth_table[row_index + 1][right_index] = "Delete"

            if truth_table[row_index + 1][right_index] != "Don't Delete":
                truth_table[row_index + 1][right_index] = "Delete"
            if is_basic_expression(left_expr) and truth_table[row_index + 1][left_index] != "Delete":
                truth_table[row_index + 1][left_index] = "Don't Delete"
            else:
                truth_table[row_index + 1][right_index] = "Delete"
        elif right_value == "0":
            #print("Right F: 1 ∨ 0")
            #truth_table[row_index + 1][left_index] = "Delete"
            if truth_table[row_index + 1][left_index] != "Don't Delete":
                truth_table[row_index + 1][left_index] = "Delete"
            if is_basic_expression(right_expr) and truth_table[row_index + 1][right_index] != "Delete":
                truth_table[row_index + 1][right_index] = "Don't Delete"
            else:
                truth_table[row_index + 1][left_index] = "Delete"
        else:
            #print("Both T: 1 ∨ 1")
            truth_table[row_index + 1][columns.index(last_item)] = "Delete"

    def process_implication():  # IMPLIES (→)
        if left_value == "1" and right_value == "0":
            #print("Left T Right F: 1 → 0")
            if is_last_item():
                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
            else:
                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
            if is_basic_expression(left_expr) or is_basic_expression(right_expr):
                handle_basic_expression()
            else:
                handle_expression()
        elif left_value == "1" and right_value == "1":
            #print("Left T: 1 → 1")

            if is_basic_expression(left_expr):
                truth_table[row_index + 1][left_index] = "Don't Delete"

            truth_table[row_index + 1][right_index] = "Delete"
        elif right_value == "0" and left_value == "0":
            #print("Right F: 0 → 0")

            if is_basic_expression(right_expr):
                truth_table[row_index + 1][right_index] = "Don't Delete"

            truth_table[row_index + 1][left_index] = "Delete"
        else:
            #print("Left F Right T: 0 → 1")
            truth_table[row_index + 1][columns.index(last_item)] = "Delete"

    def process_conjunction():  # AND (∧)
        if left_value == "1" and right_value == "1":
            #print("Both T: 1 ∧ 1")

            truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
            if is_basic_expression(left_expr) or is_basic_expression(right_expr):
                handle_basic_expression()
            else:
                handle_expression()
        elif left_value == "1":
            #print("Left T: 1 ∧ 0")
            if is_basic_expression(left_expr) or is_basic_expression(right_expr):
                if truth_table[row_index + 1][right_index] != "Don't Delete":
                    truth_table[row_index + 1][right_index] = "Delete"
                if is_basic_expression(left_expr) and truth_table[row_index + 1][left_index] != "Delete":
                    truth_table[row_index + 1][left_index] = "Don't Delete"
            else:
                truth_table[row_index + 1][right_index] = "Delete"

        elif right_value == "1":
            #print("Right T: 0 ∧ 1")
            #truth_table[row_index + 1][left_index] = "Delete"
            if truth_table[row_index + 1][left_index] != "Don't Delete":
                truth_table[row_index + 1][left_index] = "Delete"

            if is_basic_expression(right_expr) and truth_table[row_index + 1][right_index] != "Delete":
                truth_table[row_index + 1][right_index] = "Don't Delete"
            else:
                truth_table[row_index + 1][left_index] = "Delete"
        else:
            #print("Both F: 0 ∧ 0")
            truth_table[row_index + 1][columns.index(last_item)] = "Delete"
            
    def process_biconditional():  # IF (↔)
        if left_value == right_value:
            # Both T or Both F: 1 ↔ 1 or 0 ↔ 0
            if is_last_item():
                truth_table[row_index + 1][columns.index(last_item)] = "bicondition"
            else:
                truth_table[row_index + 1][columns.index(last_item)] = "bicondition"

            # ตรวจสอบว่าเป็น basic expression หรือไม่ เพื่อกำหนดการลบ
            if is_basic_expression(left_expr) or is_basic_expression(right_expr):
                handle_basic_expression()
                # สุ่มให้ฝั่งใดฝั่งหนึ่งเป็น Don't Delete
                chosen_index = random.choice([left_index, right_index])
                truth_table[row_index + 1][chosen_index] = "bicondition"
            else:
                handle_expression()
                # สุ่มให้ฝั่งใดฝั่งหนึ่งเป็น Don't Delete
                chosen_index = random.choice([left_index, right_index])
                truth_table[row_index + 1][chosen_index] = "bicondition"

        else:
            # T ↔ F or F ↔ T
            truth_table[row_index + 1][columns.index(last_item)] = "Delete"
    
    if operator == "∨":
        process_disjunction()
    elif operator == "→":
        process_implication()
    elif operator == "∧":
        process_conjunction()
    elif operator == "↔":
        process_biconditional()
    
    return truth_table 

#ลบประพจน์ปกติที่เฉลยพร้อมกันเช่น P และ ¬P
def delete_random_column(truth_table, row_index, columns):
    # หาตัวแปรที่ไม่มีนิเสธ เช่น P จาก "P", "¬P"
    variables = set()
    for col in columns:
        if not col.startswith("¬"):
            variables.add(col)

    for var in variables:
        neg_var = f"¬{var}"
        if var in columns and neg_var in columns:
            var_index = columns.index(var)
            neg_index = columns.index(neg_var)

            if (truth_table[row_index + 1][var_index] != "Delete" and
                truth_table[row_index + 1][neg_index] != "Delete"):
                
                # สุ่มลบระหว่างตัวแปรกับนิเสธของมัน
                random_pick = random.choice([var_index, neg_index])
                truth_table[row_index + 1][random_pick] = "Delete"

    return truth_table  

# แทนที่ค่า 'Delete' ใน truth_table ด้วยข้อมูลจาก correct_truth_table ในตำแหน่งเดียวกัน
def update_truth_table(truth_table, correct_truth_table):
    # ทำการวนลูปผ่านทุกแถวและคอลัมน์
    for row_index in range(len(truth_table)):
        for col_index in range(len(truth_table[row_index])):
            # ถ้าเจอ "Don't Delete" ให้เปลี่ยนเป็นค่าจาก correct_truth_table
            if truth_table[row_index][col_index] == "Don't Delete":
                truth_table[row_index][col_index] = correct_truth_table[row_index][col_index]
            if truth_table[row_index][col_index] == "bicondition":
                truth_table[row_index][col_index] = correct_truth_table[row_index][col_index]

#เปลี่ยนจาก 0 1 หรือ Delete ให้กลายเป็น T F และ '___'
def replace_values(row):
    return ['T' if val == '1' else 'F' if val == '0' else '___' if val == 'Delete' else val for val in row]                

# ฟังก์ชันตรวจสอบว่านิพจน์เป็นสมการหรือไม่
def is_equation(column_name):
    operators = ['∧', '∨', '→', '↔']  # ตัวดำเนินการที่บ่งบอกว่าเป็นสมการ
    return any(op in column_name for op in operators)

# ฟังก์ชันสร้างลิสต์นิพจน์
def get_expressions(truth_table, row_index):
    target_row = truth_table[row_index + 1]
    expr = [
        truth_table[0][i] for i in range(len(truth_table[0])) 
        if target_row[i] != "Delete" and is_equation(truth_table[0][i])
    ]
    expr_columns = [
        truth_table[0][i] for i in range(len(truth_table[0])) 
        if truth_table[1][i] != "Delete" and not is_equation(truth_table[0][i])
    ]
    return expr, expr_columns

# ฟังก์ชันหลักสำหรับประมวลผลนิพจน์
def process_expression(expression):

    # ตรวจสอบว่าเป็นนิพจน์พื้นฐานหรือไม่
    if is_basic_expression(expression):
        #print("It's not an expression")
        return None
    else:
        #print("It's an equation")
        # แยกนิพจน์
        result = split_expression(expression)
        if result:
            left_expr = remove_outer_parentheses(result["left_expression"])
            right_expr = remove_outer_parentheses(result["right_expression"])
            operator = result["operator"]
            return left_expr, operator, right_expr
        

#เทส
# ฟังก์ชันตรวจสอบว่านิพจน์เป็นค่าพื้นฐานหรือไม่
def is_basic_expression(expression):
    # ตรงกับตัวแปรเดี่ยว เช่น P, Q, A, X
    # หรือ ตรงกับ ¬ ตามด้วยตัวแปรเดี่ยว เช่น ¬P, ¬X
    return re.fullmatch(r'¬?[A-Z]', expression) is not None
    
def split_expression(expression):
    operators = ['∧', '∨', '→', '↔']
    parentheses_count = 0
    last_operator = None
    operator_position = None

    for i, char in enumerate(expression):
        if char == '(':
            parentheses_count += 1
        elif char == ')':
            parentheses_count -= 1
        elif char in operators and parentheses_count == 0:
            last_operator = char
            operator_position = i

    if last_operator and operator_position is not None:
        left_expression = expression[:operator_position].strip()
        right_expression = expression[operator_position + 1:].strip()
        return {
            "left_expression": left_expression,
            "right_expression": right_expression,
            "operator": last_operator
        }
    return None

def remove_outer_parentheses(expression):
    while expression.startswith('(') and expression.endswith(')'):
        parentheses_count = 0
        for i, char in enumerate(expression):
            if char == '(':
                parentheses_count += 1
            elif char == ')':
                parentheses_count -= 1
            if parentheses_count == 0 and i < len(expression) - 1:
                return expression
        expression = expression[1:-1].strip()
    return expression

def generate_equation( i):
    combined = ""
    type_eqt = i

    if type_eqt == 1:    
        expr = random_expr()
        oprt = random_operator()
        eqt = random_equation()
        combined = expr + oprt + eqt

    elif type_eqt == 2:
        expr = random_expr()
        oprt = random_operator()
        eqt = random_equation()
        expr_Or_eqt = random.randint(1, 2)

        random_expression = random_expr() if expr_Or_eqt == 1 else random_equation()
        random_oprt = random_operator()
        position = random.randint(1, 2)

        if position == 1:    
            combined = expr + oprt + "(" + random_expression + random_oprt + eqt + ")"
        elif position == 2:
            combined = expr + oprt + "(" + eqt + random_oprt + random_expression + ")"  

    elif type_eqt == 3:
        oprt = random_operator()
        eqt = random_equation()
        eqt1_Or_eqt2 = random.randint(1, 2)

        if eqt1_Or_eqt2 == 1:
            random_eqt = random_equation()
            combined = eqt + oprt + random_eqt
        elif eqt1_Or_eqt2 == 2:
            random_eqt_left = random_equation()
            random_oprt = random_operator()
            random_eqt_right = random_equation()
            combined = eqt + oprt + "(" + random_eqt_left + random_oprt + random_eqt_right + ")"
            
    return combined

def normalize_symbols(equation: str) -> str:
    # ลำดับการแทนที่สำคัญมาก! (→ ต้องแทนก่อน ->)
    replacements = [
        (r'->', '→'),   # → : หลีกเลี่ยง ↔ แปลงผิด
        (r'^', '∧'),         # ∧ : and
        (r'v', '∨'),          # ∨ : or (พิมพ์เล็ก)
        (r'V', '∨'),          # ∨ : or (พิมพ์ใหญ่)
        (r'~', '¬'),          # ¬ : not
        (r'=', '↔'),          # ¬ : not
    ]
    for pattern, replacement in replacements:
        equation = re.sub(pattern, replacement, equation)
    return equation


def checkPQR(truth_table, correct_truth_table, columns, rows):
    def check_all_required_flags_and_delete(truth_table, flags, columns, row_index, last_item):
        required_flags = []

        if any(col in columns for col in ('P', '¬P')):
            required_flags.append(flags['F_P'])
        if any(col in columns for col in ('Q', '¬Q')):
            required_flags.append(flags['F_Q'])
        if any(col in columns for col in ('R', '¬R')):
            required_flags.append(flags['F_R'])

        # ถ้าตัวแปรที่มีอยู่ทั้งหมดเป็น True
        if all(required_flags):
            current_index = columns.index(last_item)
            for col_index in range(current_index + 1, len(columns)):
                truth_table[row_index + 1][col_index] = 'Delete'
            return True  # ใช้บอกให้ break ได้
        return False
    
    def get_flag_value(expr, flags):
        if expr in ('P', '¬P'):
            return flags['F_P']
        elif expr in ('Q', '¬Q'):
            return flags['F_Q']
        elif expr in ('R', '¬R'):
            return flags['F_R']
        else:
            return None  # ไม่ใช่ประพจน์พื้นฐาน
    
    def check(expr, flags):
        if expr in ('P', '¬P'):
            flags['F_P'] = True
        elif expr in ('Q', '¬Q'):
            flags['F_Q'] = True
        elif expr in ('R', '¬R'):
            flags['F_R'] = True
    
    def is_basic_expression(expr):
        # สมมติว่าฟังก์ชันนี้ return True ถ้าเป็น basic expression (P, Q, R, ¬P, ¬Q, ¬R)
        return expr in ('P', 'Q', 'R', '¬P', '¬Q', '¬R')
    
    def process_expression(expr):
        # สมมติว่าฟังก์ชันนี้แยก expression และ return (left, operator, right)
        # ตัวอย่างการใช้งาน:
        operators = ['→', '∧', '∨']
        for op in operators:
            if op in expr:
                parts = expr.split(op)
                if len(parts) == 2:
                    return parts[0].strip(), op, parts[1].strip()
        return None

    # เพิ่มตัวแปร rows ที่หายไป
    rows = truth_table[1:]  # สมมติว่า rows คือข้อมูลแถวใน truth_table
    columns = truth_table[0]

    for i in range(len(rows)):
        flags = {'F_P': False, 'F_Q': False, 'F_R': False}

        row_index = i
        for praposition in columns:
            last_item = praposition
            if truth_table[row_index + 1][columns.index(last_item)] in ('T', 'F'):
                result = process_expression(last_item)
                if is_basic_expression(last_item):
                    check(last_item, flags)
                    should_break = check_all_required_flags_and_delete(truth_table, flags, columns, row_index, last_item)
                    if should_break:
                        break
                else:
                    if result:
                        left_expr, operator, right_expr = result

                        # ตรวจสอบว่า left_expr และ right_expr อยู่ใน columns หรือไม่
                        if left_expr not in columns or right_expr not in columns:
                            continue

                        left_index = columns.index(left_expr)
                        right_index = columns.index(right_expr)

                        left_value = correct_truth_table[row_index + 1][left_index]
                        right_value = correct_truth_table[row_index + 1][right_index]

                        # ตรวจสอบว่า sub-expressions ได้ถูกประมวลผลแล้วหรือไม่
                        left_processed = (not is_basic_expression(left_expr)) or (truth_table[row_index + 1][left_index] in ('T', 'F', 'Delete', "Don't Delete"))
                        right_processed = (not is_basic_expression(right_expr)) or (truth_table[row_index + 1][right_index] in ('T', 'F', 'Delete', "Don't Delete"))

                        if operator == '→':
                            # T→F = F
                            if left_value == 'T' and right_value == 'F':
                                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                if left_processed:
                                    truth_table[row_index + 1][left_index] = "Delete"
                                if right_processed:
                                    truth_table[row_index + 1][right_index] = "Delete"
                                
                                if is_basic_expression(left_expr):
                                    check(left_expr, flags)
                                if is_basic_expression(right_expr):
                                    check(right_expr, flags)
                                
                                should_break = check_all_required_flags_and_delete(truth_table, flags, columns, row_index, last_item)
                                if should_break:
                                    break

                            # T→T = T
                            elif left_value == 'T' and right_value == 'T':
                                left_flag = get_flag_value(left_expr, flags)
                                right_flag = get_flag_value(right_expr, flags)
                                
                                # ถ้าเจอซ้ายแล้ว
                                if left_flag:
                                    if right_flag:
                                        # เจอทั้งคู่แล้ว -> ลบตัวเอง
                                        truth_table[row_index + 1][columns.index(last_item)] = "Delete"
                                    else:
                                        # ยังไม่เจอขวา -> เก็บไว้
                                        truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                        if is_basic_expression(right_expr):
                                            check(right_expr, flags)
                                else:
                                    # ยังไม่เจอซ้าย -> เก็บไว้
                                    truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                    if is_basic_expression(left_expr):
                                        check(left_expr, flags)
                                    if is_basic_expression(right_expr):
                                        check(right_expr, flags)

                            # F→F = T, F→T = T
                            elif left_value == 'F':
                                right_flag = get_flag_value(right_expr, flags)
                                left_flag = get_flag_value(left_expr, flags)
                                
                                if right_flag and left_flag:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Delete"
                                else:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                    if is_basic_expression(left_expr):
                                        check(left_expr, flags)
                                    if is_basic_expression(right_expr):
                                        check(right_expr, flags)

                        elif operator == '∧':
                            # T∧T = T
                            if left_value == 'T' and right_value == 'T':
                                truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                if left_processed:
                                    truth_table[row_index + 1][left_index] = "Delete"
                                if right_processed:
                                    truth_table[row_index + 1][right_index] = "Delete"
                                
                                if is_basic_expression(left_expr):
                                    check(left_expr, flags)
                                if is_basic_expression(right_expr):
                                    check(right_expr, flags)

                            # T∧F = F
                            elif left_value == 'T' and right_value == 'F':
                                left_flag = get_flag_value(left_expr, flags)
                                right_flag = get_flag_value(right_expr, flags)
                                
                                if left_flag and right_flag:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Delete"
                                else:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                    if is_basic_expression(left_expr):
                                        check(left_expr, flags)
                                    if is_basic_expression(right_expr):
                                        check(right_expr, flags)

                            # F∧T = F
                            elif left_value == 'F' and right_value == 'T':
                                left_flag = get_flag_value(left_expr, flags)
                                right_flag = get_flag_value(right_expr, flags)
                                
                                if left_flag and right_flag:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Delete"
                                else:
                                    truth_table[row_index + 1][columns.index(last_item)] = "Don't Delete"
                                    if is_basic_expression(left_expr):
                                        check(left_expr, flags)
                                    if is_basic_expression(right_expr):
                                        check(right_expr, flags)

                        should_break = check_all_required_flags_and_delete(truth_table, flags, columns, row_index, last_item)
                        if should_break:
                            break        

#แก้ปัญหาตารางค่าความจริง จำลองการหาคำตอบ ถ้าหาไม่ได้จะ return ? ในคอลัมน์นั้นๆ
def solve_truth_table(truth_table):

    import itertools
    
    # แยก header และ data
    headers = truth_table[0]
    data_rows = truth_table[1:]
    
    # หาตัวแปรพื้นฐาน (P, Q, R)
    basic_vars = []
    for header in headers:
        if len(header) == 1 and header in ['P', 'Q', 'R']:
            basic_vars.append(header)
    basic_vars.sort()
    
    def evaluate_expression(expr, var_values):
        """ประเมินค่าของ expression ตามค่าตัวแปร"""
        if not expr:
            return False
        
        # สร้าง mapping ของตัวแปร
        var_dict = {}
        for i, var in enumerate(basic_vars):
            var_dict[var] = var_values[i]
        
        return eval_logical_expr(expr, var_dict)
    
    def eval_logical_expr(expr, var_dict):
        """ประเมิน logical expression แบบ recursive"""
        expr = expr.strip()
        
        # ถ้าเป็นตัวแปรเดี่ยว
        if expr in var_dict:
            return var_dict[expr]
        
        # ถ้าเป็น negation ของตัวแปรเดี่ยว
        if expr.startswith('¬') and len(expr) == 2 and expr[1] in var_dict:
            return not var_dict[expr[1]]
        
        # เอา parentheses ภายนอกสุดออก
        while expr.startswith('(') and expr.endswith(')') and matching_paren(expr, 0) == len(expr) - 1:
            expr = expr[1:-1].strip()
        
        # หา main operator
        main_op_pos = find_main_operator(expr)
        
        if main_op_pos is None:
            # ไม่มี operator หลัก ลองจัดการ special cases
            if expr.startswith('¬'):
                inner = expr[1:].strip()
                return not eval_logical_expr(inner, var_dict)
            return False
        
        op, pos = main_op_pos
        
        if op == '∧':
            left = expr[:pos].strip()
            right = expr[pos+1:].strip()
            return eval_logical_expr(left, var_dict) and eval_logical_expr(right, var_dict)
        elif op == '∨':
            left = expr[:pos].strip()
            right = expr[pos+1:].strip()
            return eval_logical_expr(left, var_dict) or eval_logical_expr(right, var_dict)
        elif op == '→':
            left = expr[:pos].strip()
            right = expr[pos+1:].strip()
            left_val = eval_logical_expr(left, var_dict)
            right_val = eval_logical_expr(right, var_dict)
            return (not left_val) or right_val
        elif op == '↔':
            left = expr[:pos].strip()
            right = expr[pos+1:].strip()
            left_val = eval_logical_expr(left, var_dict)
            right_val = eval_logical_expr(right, var_dict)
            return left_val == right_val
        
        return False
    
    def find_main_operator(expr):
        """หา main operator ที่มี precedence ต่ำสุด"""
        paren_depth = 0
        operators = ['↔', '→', '∨', '∧']
        
        for op in operators:
            for i in range(len(expr) - len(op) + 1):
                if expr[i] == '(':
                    paren_depth += 1
                elif expr[i] == ')':
                    paren_depth -= 1
                elif paren_depth == 0 and expr[i:i+len(op)] == op:
                    return (op, i)
        
        return None
    
    def matching_paren(expr, start):
        """หา matching parenthesis"""
        if expr[start] != '(':
            return -1
        count = 1
        for i in range(start + 1, len(expr)):
            if expr[i] == '(':
                count += 1
            elif expr[i] == ')':
                count -= 1
                if count == 0:
                    return i
        return -1
    
    def get_all_valid_solutions_for_row(row):
        """หาคำตอบทั้งหมดที่เป็นไปได้สำหรับแถวนี้"""
        valid_solutions = []
        
        # ลองทุก combination ของตัวแปรพื้นฐาน
        for combination in itertools.product([True, False], repeat=len(basic_vars)):
            valid = True
            temp_row = []
            
            # ตรวจสอบทุกคอลัมน์
            for col_idx, header in enumerate(headers):
                current_val = row[col_idx]
                
                # คำนวณค่าที่คาดหวัง
                try:
                    expected_val = evaluate_expression(header, combination)
                    expected_display = 'T' if expected_val else 'F'
                    
                    # ถ้ามีค่าที่กำหนดไว้แล้ว ต้องตรวจสอบความสอดคล้อง
                    if current_val != '___' and current_val != expected_display:
                        valid = False
                        break
                    
                    temp_row.append(expected_display)
                except:
                    valid = False
                    break
            
            if valid:
                valid_solutions.append(temp_row)
        
        return valid_solutions
    
    def resolve_row_values(row):
        """แก้ไขค่าในแถวโดยตรวจสอบว่าช่องไหนมีคำตอบเฉพาะ"""
        valid_solutions = get_all_valid_solutions_for_row(row)
        
        if not valid_solutions:
            # ไม่มีคำตอบเลย ใส่ ? ทุกช่องที่ว่าง
            result_row = row[:]
            for i in range(len(result_row)):
                if result_row[i] == '___':
                    result_row[i] = '?'
            return result_row
        
        # ตรวจสอบแต่ละคอลัมน์ว่ามีค่าเฉพาะหรือไม่
        result_row = row[:]
        for col_idx in range(len(headers)):
            if row[col_idx] == '___':
                # รวบรวมค่าที่เป็นไปได้ทั้งหมดสำหรับคอลัมน์นี้
                possible_values = set()
                for solution in valid_solutions:
                    possible_values.add(solution[col_idx])
                
                if len(possible_values) == 1:
                    # มีค่าเฉพาะ
                    result_row[col_idx] = list(possible_values)[0]
                else:
                    # มีหลายค่าที่เป็นไปได้ ไม่สามารถหาคำตอบเฉพาะได้
                    result_row[col_idx] = '?'
        
        return result_row
    
    # แก้ไขตารางแต่ละแถว
    solved_table = [headers[:]]
    
    for i, row in enumerate(data_rows):
        solved_row = resolve_row_values(row)
        solved_table.append(solved_row)
    
    return solved_table

def replace_question_rows(result, truth_table, correct_truth_table):
    """
    ฟังก์ชันแทนที่แถวที่มี ? ใน result ด้วยเฉลยประพจน์พื้นฐาน
    และนำไปแทนที่ใน truth_table โดยใช้ข้อมูลจาก correct_truth_table
    """
    result_columns = result[0]
    result_rows = result[1:]
    
    truth_table_columns = truth_table[0]
    truth_table_rows = truth_table[1:]
    
    correct_columns = correct_truth_table[0]
    correct_rows = correct_truth_table[1:]
    
    # ตรวจหาแถวที่มี ? ใน result
    for row_index, row in enumerate(result_rows):
        if '?' in row:
            # สร้างแถวใหม่สำหรับ truth_table
            new_row = ['___'] * len(truth_table_columns)
            
            # คัดลอกเฉลยประพจน์พื้นฐานจาก correct_truth_table
            for col_name in truth_table_columns:
                if is_basic_expression(col_name):
                    # หาตำแหน่งคอลัมน์ใน correct_truth_table
                    if col_name in correct_columns:
                        correct_col_index = correct_columns.index(col_name)
                        truth_table_col_index = truth_table_columns.index(col_name)
                        
                        # คัดลอกค่าจาก correct_truth_table
                        new_row[truth_table_col_index] = correct_rows[row_index][correct_col_index]
            
            # สำหรับคอลัมน์ที่ไม่ใช่ basic expression ให้เป็น '___'
            for col_index, col_name in enumerate(truth_table_columns):
                if not is_basic_expression(col_name):
                    new_row[col_index] = '___'
            
            # ใช้ delete_random_column เพื่อลบประพจน์ที่ซ้ำกัน
            temp_table = [truth_table_columns] + [new_row]
            temp_table = delete_random_column(temp_table, 0, truth_table_columns)
            new_row = temp_table[1]
            
            # แทนที่แถวใน truth_table
            truth_table_rows[row_index] = new_row
    
    # อัพเดท truth_table
    truth_table[1:] = truth_table_rows
    
    return truth_table