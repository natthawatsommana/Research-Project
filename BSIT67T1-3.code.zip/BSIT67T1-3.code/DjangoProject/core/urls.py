# core/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('api/generate-truth-table/', views.generate_truth_table_api, name='generate_truth_table_api'),
]