# core/views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

#นำเข้าฟังก์ชันจากไฟล์ logic/truth_table.py
from core.logic.truth_table import generate_truth_table_data

@csrf_exempt
def generate_truth_table_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            equation = data.get('equation')

            if not equation:
                return JsonResponse({
                    'success': False,
                    'error': 'Equation is required'
                }, status=400)

            result = generate_truth_table_data(equation)

            return JsonResponse({
                'equation': result['equation'],
                'test_data': result['test_data'],
                'correct_data': result['correct_data'],
             }, json_dumps_params={'ensure_ascii': False})

        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'error': 'Invalid JSON format'}, status=400)

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)